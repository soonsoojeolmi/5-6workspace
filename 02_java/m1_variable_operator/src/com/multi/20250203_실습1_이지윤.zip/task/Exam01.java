package com.multi.task;

public class Exam01 {
    public static void main(String[] args) {
        int width =110;
        int height =220;
        int square =width*height;

        System.out.println("사각형의 면적은 "+square+"입니다.");
    }
}

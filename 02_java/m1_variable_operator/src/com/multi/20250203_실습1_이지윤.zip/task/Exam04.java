package com.multi.task;

public class Exam04 {
    public static void main(String[] args) {
        String name = "홍길동";
        int age = 200;
        String live = "홍천";
        double weight = 88.8;
        boolean programmer = true;
        char color = 'y';

        System.out.println("친구의 이름은 "+name+"이고 나이는 "+age+"세이다.");
        System.out.println(live+"에 살고 있고 몸무게는 "+weight+"킬로이다.");
        System.out.println("좋아하는 색은 "+color+"가 들어가는 색이고, 프로그래머 여부는 "+programmer+"이다.");
    }
}

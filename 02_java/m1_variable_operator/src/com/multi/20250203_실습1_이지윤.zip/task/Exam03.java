package com.multi.task;

public class Exam03 {
    public static void main(String[] args) {
        String name="홍길동";
        String wire =  "skt";
        String num="010-1111-2222";
        String sum=(name+"님은 "+wire+"에 "+num);
        System.out.println("다이얼로그로 "+sum+"으로 가입되셨습니다.");
    }
}
